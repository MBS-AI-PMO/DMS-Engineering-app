const express = require('express');
const db = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// GET /api/settings - Public
router.get('/', async (req, res) => {
    try {
        const result = await db.query('SELECT key, value FROM site_settings');
        const settings = {};
        result.rows.forEach(row => {
            settings[row.key] = row.value;
        });
        res.json({ success: true, data: settings });
    } catch (err) {
        console.error('Error fetching settings:', err);
        res.status(500).json({ success: false, error: 'Failed to fetch settings' });
    }
});

// GET /api/settings/:key - Public
router.get('/:key', async (req, res) => {
    try {
        const result = await db.query('SELECT value FROM site_settings WHERE key = $1', [req.params.key]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Setting not found' });
        }
        res.json({ success: true, data: result.rows[0].value });
    } catch (err) {
        console.error('Error fetching setting:', err);
        res.status(500).json({ success: false, error: 'Failed to fetch setting' });
    }
});

// PUT /api/settings/:key - Admin only
router.put('/:key', authenticate, requireAdmin, async (req, res) => {
    try {
        const { value } = req.body;
        if (value === undefined) {
            return res.status(400).json({ success: false, error: 'Value is required' });
        }

        const result = await db.query(`
            UPDATE site_settings 
            SET value = $1, updated_at = CURRENT_TIMESTAMP
            WHERE key = $2
            RETURNING *
        `, [JSON.stringify(value), req.params.key]);

        if (result.rows.length === 0) {
            // Option: allow creating new keys if they don't exist
            const insertResult = await db.query(`
                INSERT INTO site_settings (key, value)
                VALUES ($1, $2)
                RETURNING *
            `, [req.params.key, JSON.stringify(value)]);
            return res.json({ success: true, data: insertResult.rows[0].value });
        }

        res.json({ success: true, data: result.rows[0].value });
    } catch (err) {
        console.error('Error updating setting:', err);
        res.status(500).json({ success: false, error: 'Failed to update setting' });
    }
});

module.exports = router;
